import os
import json
import requests
import unittest
from io import BytesIO
from flaskapp import app


class UploadTest(unittest.TestCase):
    def setUp(self):
        self.app = app
        self.app.config['TESTING'] = True
        self.client = self.app.test_client()

    def test_download(self):
        res = self.client.get('/download', data= json.dumps({"id": "test"}))
        self.assertEqual(res.status_code, 200)

##    def test_upload(self):
##        rv = self.client.post("/upload-image", buffered=True,
##                              content_type='multipart/form-data', follow_redirects=True,
##                              data=dict(upload_var=(BytesIO(b'json file'),'1.json')))
##        print(rv.data)
##        assert rv.status_code == 200

if __name__ == '__main__':
    unittest.main()
