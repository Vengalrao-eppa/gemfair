import os
import json
import datetime
from flask import jsonify, send_file, render_template, request, url_for
from flaskapp import app


@app.route("/")
def home():
    return "<h3>Welcome !.. </h3>"

@app.route("/upload-image", methods=['GET', 'POST'])
def upload_image():
    
    error = None

    if request.method == "POST":
        if request.files:
            unique_id = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            image = request.files["image"]
            image_ext = image.filename.split(".")[-1]

            # check image type is allowed or not
            if image_ext in app.config["ALLOWED_EXTENSIONS"]:
                save_image_as = "{}_{}".format(unique_id, image.filename)
                image.save(os.path.join(app.config["IMAGE_UPLOADS"], save_image_as))
                resp = jsonify({"id": unique_id})
                resp.status_code = 201
                return resp
            else:
                error = "File type not allowed.."
    return render_template('upload_image.html', error=error, types=app.config["ALLOWED_EXTENSIONS"])
 

@app.route("/download",  methods=['GET'])
def download_image():

    images = []
    image_id = request.args.get("id")
    image_ext = request.args.get("exts")

    if image_id:
        list_images = os.listdir(app.config["IMAGE_UPLOADS"])
        for image in list_images:
            if image.startswith(image_id):
                images.append(os.path.join("static", "uploads", image))
                break
    else:
        if image_ext:
            for each_image in os.listdir(app.config["IMAGE_UPLOADS"]):
                if each_image.endswith(image_ext):
                    images.append(os.path.join("static", "uploads", each_image))
                    
    return render_template('download_images.html', images=images)
    
