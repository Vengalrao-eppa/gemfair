import os
from flask import Flask


app = Flask(__name__)
app.config["BASE_DIR"] = os.path.dirname(__file__)
app.config["ALLOWED_EXTENSIONS"] = {'png', 'jpg', 'jpeg', 'gif'}
app.config["IMAGE_UPLOADS"] = os.path.join(app.config["BASE_DIR"], "static", "uploads")

from flaskapp import routes

